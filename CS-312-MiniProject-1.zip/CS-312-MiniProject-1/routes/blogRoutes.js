const express = require('express');
const router = express.Router();

let posts = [];

router.get('/', (req, res) => {
  res.render('home', { posts });
});

router.get('/new', (req, res) => {
  res.render('new');
});

router.post('/create', (req, res) => {
  const { title, content, author } = req.body;
  const createdAt = new Date().toLocaleString();
  const id = Date.now(); // unique ID
  posts.push({ id, title, content, author, createdAt });
  res.redirect('/');
});

router.get('/edit/:id', (req, res) => {
  const post = posts.find(p => p.id == req.params.id);
  res.render('edit', { post });
});

router.post('/edit/:id', (req, res) => {
  const id = req.params.id;
  posts = posts.map(post => post.id == id ? { ...post, ...req.body } : post);
  res.redirect('/');
});

router.post('/delete/:id', (req, res) => {
  posts = posts.filter(post => post.id != req.params.id);
  res.redirect('/');
});

module.exports = router;